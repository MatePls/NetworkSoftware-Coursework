/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll.system;

import java.util.Scanner;

/**
 *
 * @author w1549523
 */
public class PayrollSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner GetData = new Scanner(System.in);
        int choice;
        System.out.println("Enter 1 to register a new employee\n Enter 2 to show Full Time Employees\n Enter 3 to show Part Time Employees");
        choice =GetData.nextInt();
    }
        
        /**
         * 
         * Need to figure out what to
        switch (choice)
        {
            case 1: 
        }
      * 
      * {
      * 
      * {
    }
    */

